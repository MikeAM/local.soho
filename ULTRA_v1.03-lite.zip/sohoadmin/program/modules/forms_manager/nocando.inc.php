<?

# These arrays determine which properties options to display for which field types
# Included by: ajax-edit_compile_form.php AND ajax-properties.php

# width
$nocando_width = array("heading", "paragraph", "checkbox", "radio");

# required
$nocando_required = array("heading", "paragraph", "checkbox", "radio");

# width
$nocando_width = array("heading", "paragraph", "checkbox", "radio");

# toptitle
$nocando_toptitle = array("heading", "paragraph");

# choice
$cando_choice = array("select", "checkbox", "radio");

# multichecked
$cando_multichecked = array("checkbox", "multiselect");

# list layout
$cando_listlayout = array("checkbox", "radio");

# instructions/notes
$cando_notes = array("heading");

# maxlength
$cando_maxlength = array("text", "textarea", "email");
?>