<?php

//
//$css = $_GET['theCss'];
//$filename = 'contentStyles.txt';
//
//$cssArr = split(';', $css);
//
//$finalStyles = '';
//foreach($cssArr as $var=>$val){
//   if(strlen($val) > 0)
//      $finalStyles .= $val.";\n";
//}
//
////echo $finalStyles;
//if (!$handle = fopen($filename, 'w')) {
//   echo "Cannot open file ($filename)";
//   exit;
//}
//
//// Write $somecontent to our opened file.
//if (fwrite($handle, $finalStyles) === FALSE) {
//   echo "Cannot write to file ($filename)";
//   exit;
//}
//
//echo "Success, wrote ($finalStyles) to file ($filename)";
//
//fclose($handle);

?>