a:8:{s:15:"product_version";s:4:"4.81";s:13:"product_build";s:2:"03";s:12:"release_date";s:13:"Feb. 24, 2005";s:12:"release_time";s:10:"1109374429";s:8:"severity";s:6:"normal";s:9:"changelog";s:252:"Fixed: WMV video file display issues
Changed: Several minor text and formatting tweaks
Fixed: CSS issue with promo box titles (custom templates)
Fixed: Unable to update Page Properties
Fixed: Some areas still display PHP error reports in background";s:7:"tgzfile";s:21:"pro_v481-r03-auto.tgz";s:7:"tgzlink";s:64:"http://update.securexfer.net/install_files/pro_v481-r03-auto.tgz";}