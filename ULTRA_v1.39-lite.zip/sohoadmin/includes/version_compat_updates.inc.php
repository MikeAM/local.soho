<?php
error_reporting('E_PARSE');



?>